import 'package:cursive/core/app_export.dart';
import 'package:flutter/material.dart';

class PagetwoScreen extends StatelessWidget {
  const PagetwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
                width: mediaQueryData.size.width,
                height: mediaQueryData.size.height,
                decoration: BoxDecoration(
                    color: appTheme.amber100,
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgPagetwo),
                        fit: BoxFit.cover)),
                child: Container(
                    width: double.maxFinite,
                    padding:
                        EdgeInsets.symmetric(horizontal: 34.h, vertical: 47.v),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      CustomImageView(
                          imagePath: ImageConstant.imgBackButton,
                          height: 2.v,
                          width: 23.h,
                          alignment: Alignment.centerLeft),
                      SizedBox(height: 53.v),
                      Container(
                          width: 206.h,
                          margin: EdgeInsets.only(left: 40.h, right: 44.h),
                          child: Text("How would you like to write your words?",
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: theme.textTheme.titleLarge)),
                      SizedBox(height: 69.v),
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                              width: 88.h,
                              margin: EdgeInsets.only(left: 25.h),
                              child: Text("Pick a Category",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.titleLarge))),
                      SizedBox(height: 63.v),
                      GestureDetector(
                          onTap: () {
                            onTapTxtLettersButton(context);
                          },
                          child: Text("")),
                      SizedBox(height: 41.v),
                      GestureDetector(
                          onTap: () {
                            onTapTxtWordsButton(context);
                          },
                          child: Text("")),
                      SizedBox(height: 5.v)
                    ])))));
  }

  /// Navigates to the pagethreeScreen when the action is triggered.
  onTapTxtLettersButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.pagethreeScreen);
  }

  /// Navigates to the pagethreeScreen when the action is triggered.
  onTapTxtWordsButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.pagethreeScreen);
  }
}

import 'package:cursive/core/app_export.dart';
import 'package:flutter/material.dart';

class PageoneScreen extends StatelessWidget {
  const PageoneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            backgroundColor: appTheme.whiteA700,
            body: Container(
                width: mediaQueryData.size.width,
                height: mediaQueryData.size.height,
                decoration: BoxDecoration(
                    color: appTheme.whiteA700,
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgPageone),
                        fit: BoxFit.cover)),
                child: Container(
                    width: double.maxFinite,
                    padding:
                        EdgeInsets.symmetric(horizontal: 34.h, vertical: 47.v),
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomImageView(
                              imagePath: ImageConstant.imgBackButton,
                              height: 2.v,
                              width: 23.h),
                          SizedBox(height: 53.v),
                          Container(
                              width: 189.h,
                              margin: EdgeInsets.only(left: 45.h),
                              child: Text("What would you like \nto do?",
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.titleLarge)),
                          Spacer(),
                          Align(
                              alignment: Alignment.center,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapTxtPracticeButton(context);
                                  },
                                  child: Text(""))),
                          SizedBox(height: 41.v),
                          Align(
                              alignment: Alignment.center,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapTxtQuizButton(context);
                                  },
                                  child: Text(""))),
                          SizedBox(height: 44.v)
                        ])))));
  }

  /// Navigates to the pagetwoScreen when the action is triggered.
  onTapTxtPracticeButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.pagetwoScreen);
  }

  /// Navigates to the quizScreen when the action is triggered.
  onTapTxtQuizButton(BuildContext context) {
    Navigator.pushNamed(context, AppRoutes.quizScreen);
  }
}

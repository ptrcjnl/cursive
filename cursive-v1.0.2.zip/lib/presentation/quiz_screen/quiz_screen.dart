import 'package:cursive/core/app_export.dart';
import 'package:flutter/material.dart';

class QuizScreen extends StatelessWidget {
  const QuizScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        backgroundColor: appTheme.whiteA700,
        body: Container(
          width: mediaQueryData.size.width,
          height: mediaQueryData.size.height,
          decoration: BoxDecoration(
            color: appTheme.whiteA700,
            image: DecorationImage(
              image: AssetImage(
                ImageConstant.imgQuiz,
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(vertical: 48.v),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgBackButton,
                  height: 2.v,
                  width: 23.h,
                  margin: EdgeInsets.only(left: 34.h),
                ),
                Spacer(),
                SizedBox(height: 8.v),
                _buildRowWithImages(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRowWithImages(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgUndo59x100,
            height: 59.v,
            width: 100.h,
            margin: EdgeInsets.only(
              top: 25.v,
              bottom: 17.v,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgBoardEraser,
            height: 50.v,
            width: 82.h,
            margin: EdgeInsets.only(top: 51.v),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgChalk,
            height: 101.v,
            width: 55.h,
          ),
          CustomImageView(
            imagePath: ImageConstant.imgNext,
            height: 84.v,
            width: 102.h,
            margin: EdgeInsets.only(top: 17.v),
          ),
        ],
      ),
    );
  }
}
